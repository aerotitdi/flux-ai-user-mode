---
name: media-control
description: Управление музыкой и видео — в любом плеере Windows, во вкладке браузера и в собственном плеере FLUX
---
# Media Control

Три разных плеера, не путай их:

## 1. Системный (любой плеер Windows)
`media_status` — что играет: трек, исполнитель, плеер-приложение, позиция.
`media_control(action=...)` — play|pause|toggle|next|prev|stop|vol_up|vol_down|mute,
`volume=N` для точной громкости.
Работает через системный медиатранспорт Windows (GSMTCS): Chrome, Edge, Spotify,
Яндекс Музыка (десктоп), VK Музыка, плеер Windows. При неудаче сам откатывается
на медиа-клавиши. «Поставь музыку на паузу» = `media_control(action="pause")`.

## 2. Страница браузера (конкретная вкладка)
`browser_page_media_state` — все video/audio на странице: пауза, время, громкость, длительность.
`browser_media_control(command=...)` — play|pause|toggle|next|prev|mute|unmute|vol50|seek30|seek-30|rate1.5.
Нужно, когда важно управлять ИМЕННО этой вкладкой, а не тем, что система считает активным.

## 3. Собственный плеер FLUX (без браузера и внешних программ)
«Включи музыку у себя» = `music_play`. Играет внутри окна FLUX, ничего не запускает.
- `music_library` — что есть в фонотеке (каталог music_dir или «Музыка» пользователя);
- `music_play(query="...", loop=true, shuffle=true)` — трек/плейлист, повтор, перемешивание;
- `music_player_control(action=...)` — play|pause|toggle|next|prev|stop|loop|shuffle|volume.
Если фонотека пуста — скажи об этом и предложи либо положить файлы в music_dir,
либо открыть сервис (`media_open_service`).

## Сервисы (YouTube Music, Яндекс Музыка, VK Музыка, Spotify)
`media_open_service(service="youtube"|"yandex"|"vk"|"spotify"|"youtube_site", query="...")`
открывает сервис в браузере и ищет трек. Дальше веди страницу по skill browser-page-actions,
а звук управляй через `browser_media_control` или `media_control`.
НЕ обещай «вытащить mp3» из этих сервисов: потоки защищены, это нарушение их условий.
Управление плеером работает штатно — этого достаточно.

## Выбор, когда не сказано явно
Пользователь не уточнил, где включить музыку, — СПРОСИ и предложи свой плеер:
«Могу включить в плеере FLUX (зациклить, без браузера) или в YouTube/Яндекс/VK Музыке. Где?»
