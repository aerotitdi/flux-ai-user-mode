#!/usr/bin/env bash
# Сборка под Linux/macOS (для проверки); Windows-.exe собирается packaging/build_exe.bat
set -e
cd "$(dirname "$0")/.."
python3 -m pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --clean --name FluxChat \
  --add-data "ui:ui" --add-data "skills_bundled:skills_bundled" \
  --hidden-import websockets --hidden-import edge_tts \
  main.py
echo "Готово: dist/FluxChat/FluxChat"
