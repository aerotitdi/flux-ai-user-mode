"""Клиент лицензирования FLUX: активация, привязка к HWID, офлайн-проверка, блокировка.

ЖИЗНЕННЫЙ ЦИКЛ
  1. Первый запуск -> нет билета -> окно активации -> пользователь вводит ключ.
  2. `activate()` считает отпечаток железа (app/hwid.py) и отправляет его вместе
     с ключом на сервер лицензий.
  3. Сервер проверяет ключ, ПРИВЯЗЫВАЕТ его к этому HWID (одно устройство) и
     возвращает подписанный Ed25519 билет. Билет сохраняется в data/license.json.
  4. Дальше проверка ОФЛАЙН: подпись билета проверяется встроенным публичным ключом
     вендора, сверяется HWID и срок. Сервер не нужен каждый запуск.
  5. Раз в `heartbeat_hours` (по умолчанию 72 ч) клиент стучится на сервер:
     там проверяется отзыв. Если ключ отозван -> билет удаляется, приложение
     блокируется и требует новый ключ.
  6. Офлайн-окно билета (по умолчанию 14 дней): если всё это время нет связи,
     приложение продолжает работать, но по истечении окна требует подключения.
     Это защита от «активировал и навсегда отрезал сеть».

ПОЧЕМУ ЭТО НЕ ЛОМАЕТСЯ ПРОСТОЙ ПРАВКОЙ ФАЙЛА
  * билет подписан приватным ключом вендора, которого в поставке нет;
  * HWID зашит внутрь билета — чужой билет на этой машине не пройдёт;
  * подмена `app/_vendor_key.py` своим ключом требует пересборки приложения,
    а не правки конфига (при Nuitka/Cython-сборке это уже не текстовый файл).

ЧЕСТНЫЕ ОГРАНИЧЕНИЯ (так работает любая офлайн-лицензия, а не только эта):
  * перевод системных часов назад ловится частично — билет с `issued` в будущем
    отвергается, но «заморозка» времени между проверками не определяется;
  * полная копия системы (клон диска) даст тот же HWID. Лечится только онлайн-
    политикой «одно активное соединение» — включается флагом `strict_online`.
"""
from __future__ import annotations

import json
import os
import time
from typing import Optional

from . import hwid as HW
from .config import CONFIG, app_dir

DEFAULT_SERVER = os.environ.get("FLUX_LICENSE_SERVER", "http://127.0.0.1:8790")
STATE_NAME = "license.json"
HEARTBEAT_HOURS_DEFAULT = 72

# коды ответов сервера -> текст для пользователя
ERROR_TEXT = {
    "invalid_key": "ключ не найден или введён с опечаткой",
    "revoked": "ключ отозван разработчиком",
    "expired": "срок действия лицензии истёк",
    "already_bound": "ключ уже активирован на другом устройстве",
    "not_activated": "это устройство не активировано данным ключом",
    "rate_limited": "слишком много попыток — подожди минуту",
    "bad_hwid": "не удалось снять отпечаток устройства",
    "no_admin_token": "сервер лицензий настроен не полностью",
}


class LicenseError(Exception):
    def __init__(self, code: str, message: str, **extra):
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = extra


def state_path() -> str:
    return os.path.join(app_dir(), "data", STATE_NAME)


def _pub():
    """Публичный ключ вендора + функция проверки билета.

    НАМЕРЕННО не импортирует license_server: этого пакета нет в клиентской поставке,
    проверка подписи реализована здесь же (криптография — из `cryptography`).
    """
    return _pub_standalone()


def _pub_standalone():
    from cryptography.hazmat.primitives.serialization import load_pem_public_key
    try:
        from . import _vendor_key
        pem = (_vendor_key.VENDOR_PUBLIC_KEY or "").strip().encode()
    except Exception:
        pem = b""
    if not pem:
        raise LicenseError("no_pubkey", "в приложение не встроен публичный ключ вендора — "
                                        "сборка повреждена")

    def verify_ticket(pub, ticket: dict, hw: str, now: Optional[float] = None) -> tuple[bool, str]:
        import base64
        now = time.time() if now is None else now
        payload = (ticket or {}).get("payload")
        sig = (ticket or {}).get("sig") or ""
        if not isinstance(payload, dict) or not sig:
            return False, "билет неполный"
        try:
            canon = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                               separators=(",", ":")).encode("utf-8")
            pad = "=" * (-len(sig) % 4)
            pub.verify(base64.urlsafe_b64decode(sig + pad), canon)
        except Exception:
            return False, "подпись билета недействительна"
        if payload.get("hwid") != hw:
            return False, "билет выдан на другое устройство"
        exp = int(payload.get("expires") or 0)
        if exp and now > exp:
            return False, "лицензия истекла"
        off = int(payload.get("offline_until") or 0)
        if off and now > off:
            return False, "истёк срок офлайн-проверки — нужно подключиться к серверу лицензий"
        if now < int(payload.get("issued") or 0) - 86400:
            return False, "билет выдан в будущем — проверь системное время"
        return True, "ok"

    return load_pem_public_key(pem), verify_ticket


def server_url() -> str:
    return (CONFIG.settings.get("license_server_url") or DEFAULT_SERVER).rstrip("/")


def license_required() -> bool:
    """Можно ли запустить приложение без лицензии.

    `license_required=false` — режим разработки/сборки без сервера лицензий.
    В поставке должно быть true.
    """
    return bool(CONFIG.settings.get("license_required", True))


def _hwid() -> tuple[str, list[str], bool]:
    """(hwid, варианты, надёжно). Если железа не читается — слабая привязка по MAC."""
    raw = HW.collect()
    h = HW.hwid(raw)
    if h:
        return h, HW.hwid_variants(raw), True
    return HW.stable_fallback(), [HW.stable_fallback()], False


def _load_state() -> dict:
    try:
        with open(state_path(), "r", encoding="utf-8") as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _save_state(st: dict) -> None:
    path = state_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def clear_state() -> None:
    st = _load_state()
    st.update({"ticket": None, "revoked": True, "revoked_at": time.time()})
    _save_state(st)


# ============================================================ сетевые вызовы
async def _post(path: str, payload: dict, timeout: float = 20.0) -> dict:
    import aiohttp
    url = server_url() + path
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=timeout)) as s:
            async with s.post(url, json=payload,
                              headers={"User-Agent": "FluxDesktop/2.9"}) as r:
                try:
                    data = await r.json()
                except Exception:
                    return {"ok": False, "error": "bad_response",
                            "message": f"сервер ответил не JSON (HTTP {r.status})",
                            "status": r.status}
                data["status"] = r.status
                return data
    except Exception as e:
        return {"ok": False, "error": "network", "status": 0,
                "message": f"сервер лицензий недоступен ({url}): {type(e).__name__}: {e}"}


async def activate(key: str, server: str = "") -> dict:
    """Активировать ключ на ЭТОМ устройстве. Первая активация привязывает лицензию."""
    if server:
        CONFIG.settings["license_server_url"] = server.rstrip("/")
        CONFIG.save()
    from .license_fmt import normalize_key, key_hint
    norm = normalize_key(key)
    if not norm:
        raise LicenseError("invalid_key", "ключ введён с ошибкой: " + key_hint(key))
    hw, variants, reliable = _hwid()
    if not hw:
        raise LicenseError("bad_hwid", "не удалось снять отпечаток устройства")
    from app import __version__
    res = await _post("/v1/activate", {
        "key": norm, "hwid": hw, "hwid_variants": variants,
        "hwid_label": HW.label(), "app_version": __version__})
    if not res.get("ok"):
        code = res.get("error") or "unknown"
        raise LicenseError(code, res.get("message") or ERROR_TEXT.get(code, code),
                           bound=res.get("bound") or [], status=res.get("status"))
    st = _load_state()
    st.update({"key": norm, "ticket": res["ticket"], "hwid": hw,
               "hwid_reliable": reliable, "hwid_label": HW.label(),
               "activated_at": int(time.time()), "last_check": int(time.time()),
               "server": server_url(), "plan": res.get("plan"),
               "license_id": res.get("license_id"), "revoked": False,
               "heartbeat_hours": int(res.get("heartbeat_hours") or HEARTBEAT_HOURS_DEFAULT)})
    _save_state(st)
    return st


async def heartbeat(force: bool = False) -> dict:
    """Онлайн-проверка: не отозван ли ключ. Возвращает сводку."""
    st = _load_state()
    if not st.get("ticket"):
        return {"ok": False, "reason": "not_activated"}
    hb = int(st.get("heartbeat_hours") or HEARTBEAT_HOURS_DEFAULT)
    if not force and st.get("last_check") and (time.time() - st["last_check"]) < hb * 3600:
        return {"ok": True, "skipped": True, "checked_at": st["last_check"]}
    hw, variants, _ = _hwid()
    from app import __version__
    res = await _post("/v1/heartbeat", {"key": st.get("key", ""), "hwid": st.get("hwid") or hw,
                                        "hwid_variants": variants, "ticket": st["ticket"],
                                        "app_version": __version__})
    if res.get("revoked"):
        clear_state()
        raise LicenseError("revoked",
                           "Лицензия ОТОЗВАНА разработчиком"
                           + (f": {res.get('reason')}" if res.get("reason") else "")
                           + ". Приложение заблокировано — требуется новый ключ.")
    if res.get("ok"):
        st = _load_state()
        st["last_check"] = int(time.time())
        if res.get("ticket"):                      # сервер перевыпустил билет
            st["ticket"] = res["ticket"]
        if res.get("plan"):
            st["plan"] = res["plan"]
        st["heartbeat_hours"] = int(res.get("heartbeat_hours") or hb)
        st["revoked"] = False
        _save_state(st)
        return {"ok": True, "renewed": bool(res.get("renewed")), "plan": st.get("plan")}
    if res.get("error") == "network":
        # нет связи — не наказываем пользователя, работаем по офлайн-окну билета
        return {"ok": False, "offline": True, "reason": res.get("message", "")}
    code = res.get("error") or "unknown"
    raise LicenseError(code, res.get("message") or ERROR_TEXT.get(code, code),
                       status=res.get("status"))


async def deactivate() -> dict:
    """Освободить устройство, чтобы перенести лицензию на другой компьютер."""
    st = _load_state()
    if not st.get("key"):
        return {"ok": False, "reason": "нет активной лицензии"}
    res = await _post("/v1/deactivate", {"key": st["key"], "hwid": st.get("hwid", "")})
    try:
        os.remove(state_path())
    except OSError:
        pass
    return res


# ============================================================ локальная проверка
def validate(now: Optional[float] = None) -> dict:
    """Офлайн-проверка билета. НИКОГДА не обращается к сети.

    Возвращает {"ok": bool, "reason": str, ...}. При ok=False приложение должно
    показать окно активации.
    """
    now = time.time() if now is None else now
    if not license_required():
        return {"ok": True, "mode": "license_required=false (режим разработки)"}
    st = _load_state()
    if st.get("revoked"):
        return {"ok": False, "reason": "Лицензия отозвана. Требуется новый ключ.",
                "need_key": True}
    ticket = st.get("ticket")
    if not ticket:
        return {"ok": False, "reason": "Приложение не активировано. Введи лицензионный ключ.",
                "need_key": True}
    hw, variants, reliable = _hwid()
    if not hw:
        return {"ok": False, "reason": "Не удалось снять отпечаток устройства "
                                       "(нет доступа к данным о железе).", "need_key": False}
    stored_hw = st.get("hwid") or hw
    try:
        pub, verify_ticket = _pub()
    except LicenseError as e:
        return {"ok": False, "reason": str(e), "need_key": False}
    except Exception as e:
        return {"ok": False,
                "reason": f"Не удалось проверить лицензию: {type(e).__name__}: {e}",
                "need_key": False}

    ok, why = verify_ticket(pub, ticket, stored_hw, now)
    if not ok:
        # билет выдан на это устройство, но железо изменилось сильнее допуска —
        # пробуем варианты отпечатка (замена одного компонента)
        for v in variants:
            ok2, why2 = verify_ticket(pub, ticket, v, now)
            if ok2:
                ok, why = True, "ok (совпал вариант отпечатка)"
                break
        if not ok:
            need_key = "другое устройство" in why or "подделан" in why
            return {"ok": False, "reason": f"Проверка лицензии не пройдена: {why}",
                    "need_key": need_key, "hwid_changed": "другое устройство" in why}
    payload = (ticket or {}).get("payload") or {}
    exp = int(payload.get("expires") or 0)
    off = int(payload.get("offline_until") or 0)
    return {"ok": True, "plan": st.get("plan") or payload.get("plan"),
            "license_id": st.get("license_id") or payload.get("kid"),
            "customer": payload.get("customer") or "",
            "expires": exp, "days_left": (round((exp - now) / 86400, 1) if exp else None),
            "offline_until": off,
            "offline_days_left": round((off - now) / 86400, 1) if off else None,
            "hwid": stored_hw, "hwid_reliable": bool(st.get("hwid_reliable", reliable)),
            "hwid_label": st.get("hwid_label", ""),
            "last_check": st.get("last_check"), "activated_at": st.get("activated_at"),
            "server": st.get("server") or server_url(), "why": why}


def status() -> dict:
    """Сводка для UI: активировано ли, какой план, сколько осталось."""
    v = validate()
    st = _load_state()
    v["activated"] = bool(st.get("ticket")) and not st.get("revoked")
    v["key_masked"] = _mask(st.get("key", ""))
    v["required"] = license_required()
    v["server"] = server_url()
    v["hwid_info"] = hwid_info()      # отпечаток, которым лицензия привязана/привяжется
    return v


def _mask(key: str) -> str:
    if not key:
        return ""
    parts = key.split("-")
    if len(parts) != 5:
        return key[:4] + "…"
    return "-".join([parts[0], parts[1], "*****", "*****", parts[4]])


def require() -> tuple[bool, str]:
    """Простой шлюз для main.py: (можно запускать, причина)."""
    v = validate()
    return bool(v.get("ok")), v.get("reason", "")


def hwid_info() -> dict:
    """Что видит клиент в качестве отпечатка (для окна активации и «О программе»).

    Показываем ИМЕННО ТОТ отпечаток, который реально уходит на сервер:
    если надёжные компоненты железа не читаются (чистая виртуалка, урезанная
    сборка ОС), используется запасной по MAC — и это надо показать пользователю,
    а не отдавать пустую строку.
    """
    info = HW.info()
    hw, variants, reliable = _hwid()
    info["effective_hwid"] = hw
    info["effective_short"] = hw[:16].upper() if hw else ""
    info["reliable"] = reliable
    info["variants_count"] = len(variants)
    if not reliable:
        info["warning"] = ("Надёжный отпечаток недоступен (нет данных SMBIOS/реестра). "
                           "Привязка выполнена по MAC-адресу — она слабая: при клонировании "
                           "виртуальной машины или смене сетевого адаптера лицензия может "
                           "потребовать повторной активации.")
    return info
