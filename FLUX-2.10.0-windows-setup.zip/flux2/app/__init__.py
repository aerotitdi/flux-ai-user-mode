"""FLUX 2.0 Desktop — пакет приложения."""
__version__ = "2.10.0"
