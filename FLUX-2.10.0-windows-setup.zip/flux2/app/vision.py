"""Зрение FLUX: превращает файлы-картинки в parts для мультимодальной модели.

До этого модуля скриншот сохранялся на диск, а в диалог уходила только строка
«[изображения: C:\\...png]» — то есть модель ВИДЕЛА ПУТЬ, но не картинку.
Отсюда и «он открывает канал и не больше»: агент не мог понять, что сейчас
на экране, и не знал, куда кликать дальше.

Как устроено:
  * картинки перекодируются в JPEG и уменьшаются до `vision_max_px` по длинной
    стороне (1568 px — практический предел vision-моделей; скриншот 1080p
    в PNG весит 1-3 МБ, в JPEG после ресайза — 150-400 КБ, то есть в разы
    меньше токенов при том же качестве восприятия);
  * в диалог добавляются сообщением role=user СРАЗУ ПОСЛЕ всех ответов
    инструментов — так требует OpenAI-формат: роль tool не принимает image parts,
    а пару assistant.tool_calls / tool нельзя разрывать;
  * если Pillow нет, картинка уходит как есть (когда влезает в лимит) —
    скриншоты FLUX умеют уменьшаться ещё на этапе съёмки (параметр downscale).
"""
from __future__ import annotations

import base64
import io
import os
from typing import Any, Optional

from .config import CONFIG

DEFAULT_MAX_PX = 1568
DEFAULT_MAX_IMAGES = 3
MAX_INLINE_BYTES = 4 * 1024 * 1024      # потолок на картинку в base64 у большинства провайдеров
EXT_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp"}

# Эвристика «модель умеет смотреть». Список неполный по определению, поэтому
# НЕИЗВЕСТНАЯ модель считается зрячей (мультимодальность сегодня — норма),
# а если провайдер не умеет, он вернёт ошибку и агент откатится на текст.
_BLIND_HINTS = ("whisper", "tts", "embed", "text-embedding", "rerank", "moderation",
                "davinci", "babbage", "curie", "gpt-3.5-turbo-instruct", "-instruct-v1")


def vision_enabled(conn: Optional[dict] = None, model: str = "") -> bool:
    """Включено ли зрение: настройки -> явный флаг подключения -> эвристика по имени."""
    mode = (CONFIG.settings.get("vision_mode") or "auto").lower()
    if mode in ("on", "always", "true"):
        return True
    if mode in ("off", "never", "false"):
        return False
    if conn and conn.get("vision") is not None:
        return bool(conn["vision"])
    m = (model or "").lower()
    return not any(h in m for h in _BLIND_HINTS)


def prepare(path: str, max_px: Optional[int] = None, quality: int = 82) -> Optional[dict]:
    """Файл -> {"mime", "b64", "bytes", "src"} или None."""
    if not path or not os.path.exists(path):
        return None
    try:
        raw_size = os.path.getsize(path)
    except OSError:
        return None
    max_px = int(max_px or CONFIG.settings.get("vision_max_px") or DEFAULT_MAX_PX)
    ext = os.path.splitext(path)[1].lower()

    data: Optional[bytes] = None
    mime = EXT_MIME.get(ext, "image/png")
    try:
        from PIL import Image
        im = Image.open(path)
        im.load()
        if max(im.size) > max_px:
            k = max_px / float(max(im.size))
            im = im.resize((max(1, int(im.width * k)), max(1, int(im.height * k))))
        if im.mode in ("RGBA", "LA", "P"):
            # прозрачность -> белый фон, иначе JPEG даст чёрные квадраты
            bg = im.convert("RGBA")
            canvas = Image.new("RGB", bg.size, (255, 255, 255))
            canvas.paste(bg, mask=bg.split()[-1])
            im = canvas
        elif im.mode != "RGB":
            im = im.convert("RGB")
        buf = io.BytesIO()
        im.save(buf, "JPEG", quality=max(35, min(95, quality)), optimize=True)
        data, mime = buf.getvalue(), "image/jpeg"
    except Exception:
        data = None

    if data is None:
        if raw_size > MAX_INLINE_BYTES:
            return None
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            return None

    if len(data) > MAX_INLINE_BYTES:
        return None
    return {"mime": mime, "b64": base64.b64encode(data).decode("ascii"),
            "bytes": len(data), "src": path}


def image_part(prep: dict) -> dict:
    """Один part формата OpenAI Chat Completions."""
    return {"type": "image_url", "image_url": {"url": f"data:{prep['mime']};base64,{prep['b64']}"}}


def text_part(text: str) -> dict:
    return {"type": "text", "text": text}


def build_user_message(paths: list, note: str = "",
                       max_images: Optional[int] = None) -> Optional[dict]:
    """Сообщение role=user с картинками (None, если ничего не подготовилось).

    Вставляется ПОСЛЕ всех tool-сообщений хода.
    """
    limit = int(max_images or CONFIG.settings.get("vision_max_images") or DEFAULT_MAX_IMAGES)
    parts: list[dict[str, Any]] = []
    for p in list(paths)[:limit]:
        prep = p if isinstance(p, dict) and "b64" in p else prepare(p)
        if prep:
            parts.append(image_part(prep))
    if not parts:
        return None
    head = note or ("Снимки/изображения, которые вернули инструменты. Рассмотри их и "
                    "используй для следующего шага (что нажать, что ввести, что проверить).")
    return {"role": "user", "content": [text_part(head)] + parts}


def describe_capability(conn: Optional[dict] = None, model: str = "") -> str:
    """Строка для --selftest и панели настроек."""
    try:
        import PIL
        pil = PIL.__version__
    except Exception:
        pil = "НЕТ (ресайз недоступен, картинки уходят как есть)"
    return (f"vision={'ВКЛ' if vision_enabled(conn, model) else 'ВЫКЛ'} "
            f"режим={CONFIG.settings.get('vision_mode', 'auto')} "
            f"max_px={CONFIG.settings.get('vision_max_px') or DEFAULT_MAX_PX} "
            f"max_images={CONFIG.settings.get('vision_max_images') or DEFAULT_MAX_IMAGES} "
            f"Pillow={pil}")
