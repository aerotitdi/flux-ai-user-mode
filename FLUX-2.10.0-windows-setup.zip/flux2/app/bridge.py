"""WebSocket-мост с расширением FLUX Bridge (chrome.debugger внутри живого Chrome).

Расширение само подключается к ws://127.0.0.1:8642/bridge (исходящее соединение,
портов на Chrome нет). Протокол:
  ext -> {type:'hello'} | {type:'resp', id, result, error} | {type:'event', tabId, method, params}
  flu -> {type:'req', id, cmd, ...}   (cmd: targets|windows|activate|close|new|navigate|
                                       reload|back|forward|cdp{method,params,tabId})
"""
from __future__ import annotations

import asyncio
import json
from collections import deque
from typing import Optional

from aiohttp import web

_BR: dict = {"ws": None, "seq": 0, "futs": {}, "events": deque(maxlen=200)}


def online() -> bool:
    ws = _BR.get("ws")
    return bool(ws and not ws.closed)


async def ws_bridge(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    old = _BR.get("ws")
    if old is not None and old is not ws and not old.closed:
        await old.close()   # дубликат-подключение закрываем
    _BR["ws"] = ws

    async def keepalive():
        """Пинг каждые 20с: не даёт service worker'у расширения уснуть (MV3 idle-kill)."""
        try:
            while not ws.closed:
                await asyncio.sleep(20)
                if not ws.closed:
                    await ws.send_json({"type": "ping"})
        except Exception:
            pass

    ping_task = asyncio.create_task(keepalive())
    try:
        async for msg in ws:
            if msg.type != web.WSMsgType.TEXT:
                continue
            try:
                d = json.loads(msg.data)
            except Exception:
                continue
            if d.get("type") == "resp":
                fut = _BR["futs"].pop(d.get("id"), None)
                if fut and not fut.done():
                    fut.set_result(d)
            elif d.get("type") in ("event", "detach"):
                _BR["events"].append(d)
    finally:
        ping_task.cancel()
        if _BR.get("ws") is ws:
            _BR["ws"] = None
    return ws


class BridgeDown(Exception):
    pass


async def call(cmd: dict, timeout: float = 25.0) -> any:
    ws = _BR.get("ws")
    if not ws or ws.closed:
        raise BridgeDown("расширение FLUX Bridge не подключено (chrome://extensions -> загрузить extension/)")
    _BR["seq"] += 1
    mid = _BR["seq"]
    fut = asyncio.get_event_loop().create_future()
    _BR["futs"][mid] = fut
    await ws.send_json({**cmd, "type": "req", "id": mid})
    try:
        d = await asyncio.wait_for(fut, timeout)
    finally:
        _BR["futs"].pop(mid, None)
    if d.get("error"):
        raise BridgeDown(str(d["error"]))
    return d.get("result")


def last_events(n: int = 20) -> list:
    return list(_BR["events"])[-n:]
