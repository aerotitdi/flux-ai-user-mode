"""HTTP-сервер FLUX 2.0: UI, SSE-чат, глобальные события, таймеры, STT/TTS, CRUD
подключений, CDP-хелперы.

Добавлен `GET /api/events` — отдельный бесконечный SSE-канал ГЛОБАЛЬНЫХ событий.
Без него таймер физически не мог подать сигнал: `/api/chat` живёт только на время
одного хода чата, а срабатывание таймера происходит между ходами, когда никакого
открытого ответа к браузеру нет.
"""
from __future__ import annotations

import asyncio
import json
import os
import time

from aiohttp import web

from . import agent, bridge, events, licensing, notify, timers as TM, voicelab
from .guard_policy import POLICY
from .config import CONFIG, app_dir
from .tools import REG

UI_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ui")

HISTORIES: dict[str, list] = {}


def _mask(conn: dict) -> dict:
    c = dict(conn)
    k = c.get("api_key") or ""
    c["api_key_masked"] = (k[:4] + "…" + k[-4:]) if len(k) > 10 else ("*" * len(k) if k else "")
    c["api_key"] = k  # локально ключ виден только своему UI
    return c


async def index(request):
    return web.FileResponse(os.path.join(UI_DIR, "index.html"))


async def favicon(request):
    return web.FileResponse(os.path.join(UI_DIR, "flux.ico"))


async def api_state(request):
    mics = await asyncio.to_thread(voicelab.list_mics)
    return web.json_response({
        "settings": CONFIG.settings,
        "voice": CONFIG.voice,
        "connections": [_mask(c) for c in CONFIG.connections],
        "mics": mics,
        "tools_count": len(REG.tools),
        "tools_categories": REG.categories(),
        "license": licensing.status(),
    })


async def api_settings(request):
    data = await request.json()
    for k, v in (data.get("settings") or {}).items():
        CONFIG.settings[k] = v
    for k, v in (data.get("voice") or {}).items():
        CONFIG.voice[k] = v
    CONFIG.save()
    return web.json_response({"ok": True})


async def api_conn_save(request):
    conn = await request.json()
    saved = CONFIG.upsert_connection(conn)
    return web.json_response({"ok": True, "id": saved["id"]})


async def api_conn_delete(request):
    cid = (await request.json()).get("id")
    CONFIG.delete_connection(cid)
    return web.json_response({"ok": True})


async def api_conn_models(request):
    conn = await request.json()
    from . import providers
    try:
        models = await providers.fetch_models(conn)
        return web.json_response({"ok": True, "models": models})
    except Exception as e:
        return web.json_response({"ok": False, "error": str(e)})


async def api_conn_test(request):
    conn = await request.json()
    from . import providers
    res = await providers.test_connection(conn)
    return web.json_response(res)


async def api_voices(request):
    vs = await voicelab.voice_list_async()
    return web.json_response({"ok": True, "voices": vs})


async def api_chat(request):
    lic = licensing.validate()
    if not lic.get("ok"):
        return web.json_response({"ok": False, "error": "license",
                                  "message": lic.get("reason", "требуется активация"),
                                  "need_key": bool(lic.get("need_key"))}, status=403)
    data = await request.json()
    text = (data.get("text") or "").strip()
    sid = data.get("sid", "default")
    hist = HISTORIES.setdefault(sid, [])
    if data.get("reset"):
        hist.clear()
        return web.json_response({"ok": True})
    if not text:
        return web.json_response({"ok": False, "error": "пусто"})

    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream",
                                       "Cache-Control": "no-cache"})
    await resp.prepare(request)

    async def on_event(ev: dict):
        await resp.write(("data: " + json.dumps(ev, ensure_ascii=False) + "\n\n").encode())

    try:
        await agent.run_turn(text, hist, on_event, cookies=data.get("cookies"))
    except Exception as e:
        await on_event({"type": "error", "text": f"{type(e).__name__}: {e}"})
    await resp.write(b"data: {\"type\": \"stream_end\"}\n\n")
    return resp


async def api_stt(request):
    audio = await request.read()
    txt = await voicelab.transcribe_auto(audio)
    if txt is None:
        return web.json_response({"ok": False, "error": "STT недоступен на бэкенде; используй браузерное распознавание"},
                                 status=501)
    return web.json_response({"ok": True, "text": txt})


async def api_tts(request):
    text = request.query.get("text", "")[:2000]
    voice = request.query.get("voice") or CONFIG.voice.get("voice")
    rate, pitch = CONFIG.voice.get("rate", 0), CONFIG.voice.get("pitch", 0)
    engine = CONFIG.voice.get("tts_engine", "winget")
    if engine in ("winget", "auto"):
        url = await voicelab.winget_url(text, voice, rate, pitch)
        if url:
            asyncio.create_task(voicelab._save_copy(url))
            raise web.HTTPFound(url)   # плеер стримит mp3 напрямую, без перекачки
        if engine == "winget":
            return web.json_response({"ok": False, "error": "wingetgui недоступен"}, status=502)
    path = await voicelab.synth_to_file(text, voice)
    if not path:
        return web.json_response({"ok": False, "error": "edge-tts не установлен"}, status=501)
    return web.FileResponse(path, headers={"Content-Type": "audio/mpeg"})


async def api_shots(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "shots", name))


async def api_audio(request):
    name = os.path.basename(request.match_info["name"])
    return web.FileResponse(os.path.join(app_dir(), "data", "audio", name))


async def api_cdp(request):
    """Жив ли браузер-мост: расширение FLUX Bridge, 9222 или DevToolsActivePort."""
    from . import browser_cdp as cdp
    if bridge.online():
        try:
            tabs = await bridge.call({"cmd": "targets"})
            return web.json_response({"ok": True, "browser": "Chrome (расширение FLUX Bridge, живой)", "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if await cdp.discover():
        try:
            v = await cdp.version()
            tabs = await cdp.targets()
            return web.json_response({"ok": True, "browser": v.get("Browser", ""), "tabs": len(tabs)})
        except Exception as e:
            return web.json_response({"ok": False, "error": str(e)[:120]})
    if cdp.chrome_running():
        return web.json_response({"ok": False, "error": cdp.FRIENDLY_HINT})
    return web.json_response({"ok": False, "error": "браузер не запущен; FLUX поднимет его при первом browser-тулзе"})


async def api_browser_launch(request):
    from . import browser_cdp as cdp
    ok = await cdp.ensure_ready()
    return web.json_response({"ok": ok})


async def api_license(request):
    """Состояние лицензии для окна активации и панели «О программе»."""
    # hwid_info уже внутри status(): его используют и этот эндпоинт, и --selftest
    return web.json_response({"ok": True, **licensing.status()})


async def api_license_activate(request):
    data = await request.json()
    try:
        st = await licensing.activate(str(data.get("key") or ""),
                                      str(data.get("server") or ""))
    except licensing.LicenseError as e:
        return web.json_response({"ok": False, "error": e.code, "message": e.message,
                                  "bound": e.extra.get("bound") or []}, status=400)
    except Exception as e:
        return web.json_response({"ok": False, "error": "unexpected",
                                  "message": f"{type(e).__name__}: {e}"}, status=500)
    events.publish({"type": "license", "state": "activated", "plan": st.get("plan")})
    return web.json_response({"ok": True, "plan": st.get("plan"),
                              "license_id": st.get("license_id"),
                              "message": "лицензия активирована"})


async def api_license_check(request):
    """Принудительная онлайн-проверка: не отозван ли ключ."""
    try:
        r = await licensing.heartbeat(force=True)
    except licensing.LicenseError as e:
        events.publish({"type": "license", "state": "blocked", "reason": e.message})
        return web.json_response({"ok": False, "error": e.code, "message": e.message},
                                 status=403)
    return web.json_response({"ok": True, **r})


async def api_license_deactivate(request):
    """Освободить это устройство (перенос лицензии на другой компьютер)."""
    r = await licensing.deactivate()
    events.publish({"type": "license", "state": "deactivated"})
    return web.json_response({"ok": True, **r})


async def api_events(request):
    """Бесконечный SSE-поток глобальных событий: таймеры, уведомления, статус браузера.

    Клиент (ui/index.html) держит его открытым всё время жизни окна и получает
    `timer_fired` даже когда чат молчит — именно так доходит звук и плашка.
    """
    resp = web.StreamResponse(headers={"Content-Type": "text/event-stream",
                                       "Cache-Control": "no-cache, no-transform",
                                       "Connection": "keep-alive",
                                       "X-Accel-Buffering": "no"})
    await resp.prepare(request)
    events.EVENTS.bind_current()
    q = await events.EVENTS.subscribe(replay=int(request.query.get("replay", 0)))
    try:
        await resp.write(events.sse_line({"type": "hello", "ts": time.time(),
                                          "timers": TM.SCHED.snapshot()["next"]}))
        while True:
            try:
                ev = await asyncio.wait_for(q.get(), timeout=15.0)
                await resp.write(events.sse_line(ev))
            except asyncio.TimeoutError:
                await resp.write(b": keep-alive\n\n")     # комментарий SSE, не событие
    except (asyncio.CancelledError, ConnectionResetError, ConnectionError):
        pass
    finally:
        events.EVENTS.unsubscribe(q)
    return resp


async def api_timers(request):
    """Снимок состояния таймеров для панели в UI."""
    snap = TM.SCHED.snapshot()
    return web.json_response({"ok": True, **snap})


async def api_timers_action(request):
    """Создать/отменить/отложить таймер прямо из интерфейса (без модели)."""
    data = await request.json()
    act = (data.get("action") or "set").lower()
    try:
        if act == "set":
            t = TM.SCHED.set_timer(data.get("when") or data.get("seconds") or 60,
                                   data.get("label") or "таймер",
                                   sound=bool(data.get("sound", True)),
                                   note=data.get("note") or "")
            return web.json_response({"ok": True, "timer": t.to_dict()})
        if act == "cancel":
            t = TM.SCHED.cancel(str(data.get("id", "")))
            return web.json_response({"ok": True, "timer": t.to_dict()})
        if act == "snooze":
            t = TM.SCHED.snooze(str(data.get("id", "")), data.get("delay") or "5 минут")
            return web.json_response({"ok": True, "timer": t.to_dict()})
        if act == "pause":
            return web.json_response({"ok": True, "timer": TM.SCHED.pause(str(data.get("id", ""))).to_dict()})
        if act == "resume":
            return web.json_response({"ok": True, "timer": TM.SCHED.resume(str(data.get("id", ""))).to_dict()})
        if act == "ack":
            return web.json_response({"ok": True, "acked": len(TM.SCHED.unacked())})
        return web.json_response({"ok": False, "error": f"неизвестное действие: {act}"}, status=400)
    except (KeyError, ValueError) as e:
        return web.json_response({"ok": False, "error": str(e)}, status=400)
    except Exception as e:
        return web.json_response({"ok": False, "error": f"{type(e).__name__}: {e}"}, status=500)


async def api_notify_stop(request):
    """Мгновенно заглушить сирену (кнопка «Выключить» в плашке таймера)."""
    ok = notify.stop_sound()
    return web.json_response({"ok": True, "stopped": ok})


async def api_notify_test(request):
    sound = request.query.get("sound", "alarm")
    path = notify.sound_path(sound)
    ch = notify.play(sound, repeat=1, force=True)
    notify.notify("test", "Проверка уведомлений", f"канал звука: {ch}", sound="chime", repeat=1)
    return web.json_response({"ok": True, "channel": ch, "wav": path, "diag": notify.selftest()})


async def api_guard_pending(request):
    """Запросы на подтверждение привилегированных действий (страж ПК)."""
    return web.json_response({"ok": True, "mode": POLICY.mode,
                              "pending": POLICY.pending_list()})


async def api_guard_confirm(request):
    """Пользователь разрешил/запретил действие. Возвращает одноразовый токен."""
    data = await request.json()
    res = POLICY.approve(str(data.get("id", "")), bool(data.get("allow")),
                         str(data.get("note") or ""))
    return web.json_response(res, status=200 if res.get("ok") else 404)


async def api_guard_audit(request):
    return web.json_response({"ok": True, "mode": POLICY.mode,
                              "records": POLICY.read_audit(int(request.query.get("limit", 100)),
                                                           request.query.get("filter", ""))})


async def api_music_file(request):
    """Отдаёт трек собственному плееру FLUX (только из каталога фонотеки)."""
    from .tools.media import music_dir
    name = os.path.basename(request.match_info["name"])
    root = music_dir()
    full = None
    for dirpath, _dirs, files in os.walk(root):
        if name in files:
            full = os.path.join(dirpath, name)
            break
    if not full:
        raise web.HTTPNotFound(text="трек не найден в фонотеке")
    ext = os.path.splitext(full)[1].lower()
    mime = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac",
            ".wav": "audio/wav", ".ogg": "audio/ogg", ".opus": "audio/ogg",
            ".flac": "audio/flac", ".webm": "audio/webm"}.get(ext, "application/octet-stream")
    return web.FileResponse(full, headers={"Content-Type": mime,
                                           "Cache-Control": "no-store"})


async def api_music_list(request):
    from .tools.media import scan_library, music_dir
    lib = scan_library(int(request.query.get("limit", 400)))
    return web.json_response({"ok": True, "dir": music_dir(),
                              "count": len(lib),
                              "tracks": [{"name": t["name"], "file": os.path.basename(t["path"]),
                                          "folder": t["folder"], "mb": t["mb"]} for t in lib]})


async def api_tools(request):
    q = request.query.get("q", "")
    specs = REG.search(q, int(request.query.get("k", 20))) if q else list(REG.tools.values())[:50]
    return web.json_response({"count": len(REG.tools),
                              "tools": [{"name": s.name, "desc": s.description, "cat": s.category} for s in specs]})


async def api_runcode(request):
    """Интерпретатор кода для кнопок «▶ запустить» у код-блоков в чате."""
    from .tools import codrun
    data = await request.json()
    res = await asyncio.to_thread(codrun.run_code, data.get("engine", "python"),
                                  data.get("code", ""), data.get("stdin", ""), 25)
    return web.json_response(res)


async def _license_watchdog() -> None:
    """Периодическая онлайн-проверка: если ключ отозвали — блокируем сразу,
    не дожидаясь истечения офлайн-окна билета."""
    while True:
        try:
            await asyncio.sleep(6 * 3600)
            if not licensing.license_required() or not licensing._load_state().get("ticket"):
                continue
            await licensing.heartbeat()
        except licensing.LicenseError as e:
            events.publish({"type": "license", "state": "blocked",
                            "reason": str(e), "code": e.code})
        except asyncio.CancelledError:
            raise
        except Exception:
            pass


async def _on_startup(app: web.Application) -> None:
    """Шина событий должна знать loop сервера, иначе публикация из потока таймера
    никуда не долетит. И поднимаем планировщик, даже если main.py его не запустил."""
    events.EVENTS.bind_current()
    TM.start()
    app["license_watchdog"] = asyncio.create_task(_license_watchdog())


async def _on_cleanup(app: web.Application) -> None:
    t = app.get("license_watchdog")
    if t:
        t.cancel()


async def _on_shutdown(app: web.Application) -> None:
    TM.stop()


def build_app() -> web.Application:
    app = web.Application(client_max_size=40 * 1024 * 1024)
    app.on_startup.append(_on_startup)
    app.on_cleanup.append(_on_cleanup)
    app.on_shutdown.append(_on_shutdown)
    app.router.add_get("/", index)
    app.router.add_get("/favicon.ico", favicon)
    app.router.add_get("/api/state", api_state)
    app.router.add_post("/api/settings", api_settings)
    app.router.add_post("/api/conn/save", api_conn_save)
    app.router.add_post("/api/conn/delete", api_conn_delete)
    app.router.add_post("/api/conn/models", api_conn_models)
    app.router.add_post("/api/conn/test", api_conn_test)
    app.router.add_get("/api/voices", api_voices)
    app.router.add_post("/api/chat", api_chat)
    app.router.add_post("/api/stt", api_stt)
    app.router.add_get("/api/tts", api_tts)
    app.router.add_get("/api/shots/{name}", api_shots)
    app.router.add_get("/api/audio/{name}", api_audio)
    app.router.add_post("/api/browser/launch", api_browser_launch)
    app.router.add_get("/api/cdp", api_cdp)
    app.router.add_get("/bridge", bridge.ws_bridge)
    app.router.add_get("/api/tools", api_tools)
    app.router.add_get("/api/guard/pending", api_guard_pending)
    app.router.add_post("/api/guard/confirm", api_guard_confirm)
    app.router.add_get("/api/guard/audit", api_guard_audit)
    app.router.add_get("/api/music/{name}", api_music_file)
    app.router.add_get("/api/music-list", api_music_list)
    app.router.add_get("/api/events", api_events)
    app.router.add_get("/api/license", api_license)
    app.router.add_post("/api/license/activate", api_license_activate)
    app.router.add_post("/api/license/check", api_license_check)
    app.router.add_post("/api/license/deactivate", api_license_deactivate)
    app.router.add_get("/api/timers", api_timers)
    app.router.add_post("/api/timers", api_timers_action)
    app.router.add_post("/api/notify/stop", api_notify_stop)
    app.router.add_get("/api/notify/test", api_notify_test)
    app.router.add_post("/api/runcode", api_runcode)
    return app
