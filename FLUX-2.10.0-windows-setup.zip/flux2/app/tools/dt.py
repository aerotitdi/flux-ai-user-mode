"""Дата и время (18)."""
from __future__ import annotations

import calendar
import datetime as dtm
import time
from zoneinfo import ZoneInfo, available_timezones

from .registry import P, REG

C = "datetime"
T = REG.tool


def _parse(s):
    s = s.strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d.%m.%Y %H:%M", "%d.%m.%Y"):
        try:
            return dtm.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return dtm.datetime.fromisoformat(s)


@T("dt_now", "Текущие дата/время (опц. таймзона)", [P("tz", desc="таймзона IANA", required=False, default="")], C)
def _(ctx, tz):
    now = dtm.datetime.now(ZoneInfo(tz)) if tz else dtm.datetime.now().astimezone()
    return now.isoformat(timespec="seconds")


@T("dt_unix_to_iso", "Unix timestamp -> ISO строка", [P("ts", "integer", desc="unix seconds"), P("tz", desc="таймзона", required=False, default="")], C)
def _(ctx, ts, tz):
    d = dtm.datetime.fromtimestamp(ts, ZoneInfo(tz) if tz else None)
    return d.isoformat(timespec="seconds")


@T("dt_iso_to_unix", "ISO строка/дата -> unix timestamp", [P("value", desc="ISO или YYYY-MM-DD")], C)
def _(ctx, value): return int(_parse(value).timestamp())


@T("dt_format", "Отформатировать дату (strftime)", [P("value", desc="дата"), P("fmt", desc="strftime формат", required=False, default="%d.%m.%Y %H:%M")], C)
def _(ctx, value, fmt): return _parse(value).strftime(fmt)


@T("dt_diff", "Разница между двумя датами (дней/часов/минут)", [P("a", desc="дата 1"), P("b", desc="дата 2")], C)
def _(ctx, a, b):
    d = _parse(b) - _parse(a)
    secs = int(d.total_seconds())
    return f"дней={d.days} часов={secs // 3600} минут={secs // 60} секунд={secs}"


@T("dt_add", "Прибавить/убавить интервал к дате", [P("value", desc="дата"), P("days", "integer", desc="дней", required=False, default=0),
                                                   P("hours", "integer", desc="часов", required=False, default=0), P("minutes", "integer", desc="минут", required=False, default=0)], C)
def _(ctx, value, days, hours, minutes):
    return (_parse(value) + dtm.timedelta(days=days, hours=hours, minutes=minutes)).isoformat(timespec="seconds")


@T("dt_weekday", "День недели даты", [P("value", desc="дата")], C)
def _(ctx, value):
    return ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"][_parse(value).weekday()]


@T("dt_week_number", "Номер недели ISO", [P("value", desc="дата")], C)
def _(ctx, value): return _parse(value).isocalendar()[1]


@T("dt_quarter", "Квартал года даты", [P("value", desc="дата")], C)
def _(ctx, value): return (_parse(value).month - 1) // 3 + 1


@T("dt_leap_year", "Високосный ли год", [P("year", "integer", desc="год")], C)
def _(ctx, year): return "да" if calendar.isleap(year) else "нет"


@T("dt_age", "Возраст от даты рождения до сегодня", [P("birth", desc="дата рождения")], C)
def _(ctx, birth):
    b = _parse(birth)
    now = dtm.datetime.now()
    years = now.year - b.year - ((now.month, now.day) < (b.month, b.day))
    days = (now.date() - b.date()).days
    return f"лет={years} дней_всего={days}"


@T("dt_days_until", "Сколько дней до даты", [P("value", desc="дата")], C)
def _(ctx, value): return (_parse(value).date() - dtm.datetime.now().date()).days


@T("dt_timezone_convert", "Перевести время между таймзонами", [P("value", desc="дата/время"), P("src_tz", desc="откуда IANA"), P("dst_tz", desc="куда IANA")], C)
def _(ctx, value, src_tz, dst_tz):
    d = _parse(value).replace(tzinfo=ZoneInfo(src_tz))
    return d.astimezone(ZoneInfo(dst_tz)).isoformat(timespec="seconds")


@T("dt_timezones_list", "Список доступных IANA таймзон (фильтр по подстроке)", [P("filter", desc="фильтр", required=False, default="")], C)
def _(ctx, filter):
    zs = sorted(z for z in available_timezones() if filter.lower() in z.lower())
    return "\n".join(zs[:120]) or "ничего не найдено"


@T("dt_workdays_between", "Число рабочих дней между датами", [P("a", desc="дата 1"), P("b", desc="дата 2")], C)
def _(ctx, a, b):
    d1, d2 = sorted([_parse(a).date(), _parse(b).date()])
    n = 0
    cur = d1
    while cur <= d2:
        if cur.weekday() < 5:
            n += 1
        cur += dtm.timedelta(days=1)
    return n


@T("dt_timestamp_ms", "Текущий unix timestamp в миллисекундах", [], C)
def _(ctx): return int(time.time() * 1000)


@T("dt_month_calendar", "Календарь месяца текстом", [P("year", "integer", desc="год"), P("month", "integer", desc="месяц 1-12")], C)
def _(ctx, year, month): return calendar.TextCalendar(firstweekday=0).formatmonth(year, month)


@T("dt_human_relative", "Дата в относительном виде ('3 дня назад')", [P("value", desc="дата ISO")], C)
def _(ctx, value):
    d = _parse(value)
    if d.tzinfo is None:
        d = d.astimezone()
    delta = dtm.datetime.now().astimezone() - d
    secs = int(delta.total_seconds())
    if abs(secs) < 60:
        return "только что"
    mins = secs // 60
    if abs(mins) < 60:
        return f"{mins} мин назад" if mins > 0 else f"{-mins} мин через"
    hours = mins // 60
    if abs(hours) < 24:
        return f"{hours} ч назад" if hours > 0 else f"{-hours} ч через"
    days = hours // 24
    return f"{days} дн назад" if days > 0 else f"{-days} дн через"
