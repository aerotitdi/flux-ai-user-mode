"""Управление компьютером (JARVIS-like): окна, мышь, клавиатура, экран, OCR, процессы.

Закрывает категории списка тулов: pyautogui/pynput/pywinauto/pywin32/user32 SendInput/
ShowWindow/clipboard, PowerShell, xdotool/wmctrl (Linux), osascript/System Events (macOS).
Бэкенды: Windows - ctypes(user32)+SendInput+PowerShell(OCR WinRT); Linux - xdotool/wmctrl;
macOS - osascript. Если установлен pyautogui - используется он (точнее и проще).
"""
from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import time

from .. import winproc
from ..config import app_dir
from .registry import P, REG, ToolResult

C = "computer"
T = REG.tool

try:
    import pyautogui as _PA
    _PA.FAILSAFE = False
except Exception:
    _PA = None

NT = os.name == "nt"
MAC = os.uname().sysname == "Darwin" if hasattr(os, "uname") else False
LNX = not NT and not MAC

# ---------------------------------------------------------------- backends
def _ps(cmd: str, timeout: int = 20) -> str:
    """PowerShell БЕЗ всплывающего окна консоли (см. app/winproc.py).

    Раньше здесь был голый subprocess.run(...) — при запуске из .exe без консоли
    Windows выделяла powershell.exe новое консольное окно, и оно мигало на экране
    при каждом скриншоте/OCR/буфере обмена.
    """
    return winproc.ps(cmd, timeout=timeout)


def _sh(cmd: list[str], timeout: int = 20) -> str:
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return (r.stdout or r.stderr).strip()


def _need(tool: str) -> str:
    return shutil.which(tool) or ""


if NT:
    _u32 = ctypes.windll.user32

    def _enum_windows():
        import ctypes.wintypes as wt
        out = []

        @ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
        def cb(hwnd, lparam):
            if _u32.IsWindowVisible(hwnd):
                n = _u32.GetWindowTextLengthW(hwnd) + 1
                buf = ctypes.create_unicode_buffer(n)
                _u32.GetWindowTextW(hwnd, buf, n)
                if buf.value.strip():
                    out.append((hwnd, buf.value))
            return True

        _u32.EnumWindows(cb, 0)
        return out

    def _find_win(title: str):
        for h, t in _enum_windows():
            if title.lower() in t.lower():
                return h, t
        return None, None

    class _INPUT(ctypes.Structure):
        class _U(ctypes.Union):
            class _MOUSE(ctypes.Structure):
                _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                            ("data", ctypes.c_long), ("flags", ctypes.c_ulong),
                            ("time", ctypes.c_ulong), ("extra", ctypes.POINTER(ctypes.c_ulong))]
            class _KEY(ctypes.Structure):
                _fields_ = [("vk", ctypes.c_ushort), ("scan", ctypes.c_ushort),
                            ("flags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                            ("extra", ctypes.POINTER(ctypes.c_ulong))]
            _fields_ = [("mouse", _MOUSE), ("key", _KEY), ("pad", ctypes.c_byte * 8)]
        _fields_ = [("type", ctypes.c_ulong), ("u", _U)]

    def _send(inputs: list):
        n = len(inputs)
        arr = (_INPUT * n)(*inputs)
        _u32.SendInput(n, ctypes.byref(arr), ctypes.sizeof(_INPUT))

    def _mouse_input(flags, dx=0, dy=0, data=0):
        i = _INPUT()
        i.type = 0
        i.u.mouse.dx, i.u.mouse.dy, i.u.mouse.data, i.u.mouse.flags = dx, dy, data, flags
        return i

    def _key_input(vk, flags):
        i = _INPUT()
        i.type = 1
        i.u.key.vk, i.u.key.flags = vk, flags
        return i

    VK = {"enter": 0x0D, "tab": 0x09, "escape": 0x1B, "esc": 0x1B, "space": 0x20, "backspace": 0x08,
          "delete": 0x2E, "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27, "home": 0x24,
          "end": 0x23, "pageup": 0x21, "pagedown": 0x22, "win": 0x5B, "alt": 0x12, "ctrl": 0x11,
          "control": 0x11, "shift": 0x10, "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74,
          "f6": 0x75, "f7": 0x76, "f8": 0x77, "f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B}


def _err_os() -> ToolResult:
    return ToolResult(False, "недоступно на этой ОС")


# ---------------------------------------------------------------- окна ОС
@T("os_windows_list", "Список окон ОС (заголовок, hwnd, свёрнуто/развёрнуто) - аналог pyautogui.getAllWindows / wmctrl -l / CGWindowList", [], C, core=True)
def _(ctx):
    if NT:
        out = []
        for h, t in _enum_windows():
            st = "свёрнуто" if _u32.IsIconic(h) else "развёрнуто" if _u32.IsZoomed(h) else "обычное"
            out.append(f"{h} | {t} | {st}")
        return "\n".join(out[:80]) or "окон нет"
    if LNX and _need("wmctrl"):
        return _sh(["wmctrl", "-l"])
    if MAC:
        return _sh(["osascript", "-e", 'tell app "System Events" to get name of every process whose visible is true'])
    return _err_os()


@T("os_window_focus", "Вывести окно ОС на передний план по части заголовка (SetForegroundWindow / wmctrl -a / AX raise)", [P("title", desc="часть заголовка")], C, core=True)
def _(ctx, title):
    if NT:
        h, t = _find_win(title)
        if not h:
            return ToolResult(False, f"окно не найдено: {title}")
        _u32.ShowWindow(h, 9)
        _u32.SetForegroundWindow(h)
        return f"активировано: {t}"
    if LNX and _need("wmctrl"):
        return _sh(["wmctrl", "-a", title]) or f"активировано: {title}"
    if MAC:
        return _sh(["osascript", "-e", f'tell app "System Events" to set frontmost of first process whose name contains "{title}" to true'])
    return _err_os()


def _win_state(title: str, sw: int, verb: str):
    if NT:
        h, t = _find_win(title)
        if not h:
            return ToolResult(False, f"окно не найдено: {title}")
        _u32.ShowWindow(h, sw)
        return f"{verb}: {t}"
    if LNX and _need("xdotool"):
        wid = _sh(["xdotool", "search", "--name", title]).split("\n")[0]
        if not wid:
            return ToolResult(False, f"окно не найдено: {title}")
        if sw == 6:
            _sh(["xdotool", "windowminimize", wid])
        elif sw == 3:
            _sh(["xdotool", "windowmaximize", wid] if _need("xdotool") else ["true"])
        else:
            _sh(["xdotool", "windowraise", wid])
        return f"{verb}: {title}"
    if MAC:
        val = {6: "true", 3: "false", 9: "false"}[sw]
        return _sh(["osascript", "-e",
                    f'tell app "System Events" to set value of attribute "AXMinimized" of window 1 of first process whose name contains "{title}" to {val}'])
    return _err_os()


@T("os_window_minimize", "Свернуть окно ОС по части заголовка (ShowWindow SW_MINIMIZE / AHK WinMinimize / xdotool windowminimize)", [P("title", desc="часть заголовка")], C, core=True)
def _(ctx, title):
    if NT and title.strip() == "__all__":
        _ps("(New-Object -ComObject Shell.Application).MinimizeAll()")
        return "свёрнуты все окна"
    return _win_state(title, 6, "свёрнуто")


@T("os_window_maximize", "Развернуть окно ОС на весь экран", [P("title", desc="часть заголовка")], C)
def _(ctx, title): return _win_state(title, 3, "развёрнуто")


@T("os_window_restore", "Восстановить окно ОС из свёрнутого/развёрнутого", [P("title", desc="часть заголовка")], C)
def _(ctx, title): return _win_state(title, 9, "восстановлено")


@T("os_window_close", "Закрыть окно ОС (WM_CLOSE / AHK WinClose / wmctrl -c)", [P("title", desc="часть заголовка")], C)
def _(ctx, title):
    if NT:
        h, t = _find_win(title)
        if not h:
            return ToolResult(False, f"окно не найдено: {title}")
        _u32.PostMessageW(h, 0x0010, 0, 0)
        return f"закрыто: {t}"
    if LNX and _need("wmctrl"):
        return _sh(["wmctrl", "-c", title]) or f"закрыто: {title}"
    if MAC:
        return _sh(["osascript", "-e", f'tell app "{title}" to quit'])
    return _err_os()


@T("os_window_move", "Переместить/изменить размер окна ОС (MoveWindow / AHK WinMove / wmctrl -e)", [P("title", desc="часть заголовка"), P("x", "integer", desc="x"), P("y", "integer", desc="y"), P("w", "integer", desc="ширина", required=False, default=0), P("h", "integer", desc="высота", required=False, default=0)], C)
def _(ctx, title, x, y, w, h):
    if NT:
        import ctypes.wintypes as wt
        hh, t = _find_win(title)
        if not hh:
            return ToolResult(False, f"окно не найдено: {title}")
        r = wt.RECT()
        _u32.GetWindowRect(hh, ctypes.byref(r))
        w = w or (r.right - r.left)
        h = h or (r.bottom - r.top)
        _u32.MoveWindow(hh, x, y, w, h, True)
        return f"окно {t}: {x},{y} {w}x{h}"
    if LNX and _need("xdotool"):
        wid = _sh(["xdotool", "search", "--name", title]).split("\n")[0]
        if not wid:
            return ToolResult(False, "окно не найдено")
        _sh(["xdotool", "windowmove", wid, str(x), str(y)])
        if w and h:
            _sh(["xdotool", "windowsize", wid, str(w), str(h)])
        return "перемещено"
    return _err_os()


@T("os_active_window", "Заголовок активного окна ОС (GetForegroundWindow / xdotool getactivewindow)", [], C)
def _(ctx):
    if NT:
        h = _u32.GetForegroundWindow()
        n = _u32.GetWindowTextLengthW(h) + 1
        buf = ctypes.create_unicode_buffer(n)
        _u32.GetWindowTextW(h, buf, n)
        return buf.value or "(без заголовка)"
    if LNX and _need("xdotool"):
        wid = _sh(["xdotool", "getactivewindow"])
        return _sh(["xdotool", "getwindowname", wid])
    if MAC:
        return _sh(["osascript", "-e", 'tell app "System Events" to get name of first process whose frontmost is true'])
    return _err_os()


@T("os_minimize_all", "Свернуть ВСЁ (Show Desktop / Win+D / AutoIt WinMinimizeAll)", [], C)
def _(ctx):
    if NT:
        _ps("(New-Object -ComObject Shell.Application).MinimizeAll()")
        return "рабочий стол показан"
    if LNX and _need("wmctrl"):
        return _sh(["wmctrl", "-k", "on"])
    if MAC:
        return _sh(["osascript", "-e", 'tell app "System Events" to key code 103 using {command down, option down}'])
    return _err_os()


# ---------------------------------------------------------------- мышь
def _mouse_click(x, y, button, clicks):
    if _PA:
        _PA.click(x=x or None, y=y or None, button=button, clicks=clicks)
        return
    if NT:
        if x is not None and y is not None:
            _mouse_move(x, y)
        DOWN = {"left": 0x0002, "right": 0x0008, "middle": 0x0020}
        UP = {"left": 0x0004, "right": 0x0010, "middle": 0x0040}
        for _ in range(max(1, clicks)):
            _send([_mouse_input(DOWN[button]), _mouse_input(UP[button])])
            time.sleep(0.05)
        return
    if LNX and _need("xdotool"):
        b = {"left": "1", "middle": "2", "right": "3"}[button]
        if x is not None and y is not None:
            _sh(["xdotool", "mousemove", str(x), str(y)])
        _sh(["xdotool", "click", "--repeat", str(clicks), b])
        return
    if MAC:
        return _sh(["osascript", "-e", f'tell app "System Events" to click at {{{x},{y}}}'])
    raise RuntimeError("нет бэкенда мыши (поставь pyautogui или xdotool)")


def _mouse_move(x, y):
    if _PA:
        _PA.moveTo(x, y)
        return
    if NT:
        sx, sy = _u32.GetSystemMetrics(0), _u32.GetSystemMetrics(1)
        _send([_mouse_input(0x0001 | 0x8000, int(x * 65535 / sx), int(y * 65535 / sy))])
        return
    if LNX and _need("xdotool"):
        _sh(["xdotool", "mousemove", str(x), str(y)])
        return
    raise RuntimeError("нет бэкенда мыши")


@T("mouse_click", "Клик мышью (координаты опц., кнопка left/right/middle, клики N) - pyautogui.click / AHK Click / xdotool click", [P("button", desc="кнопка", required=False, default="left", enum=["left", "right", "middle"]), P("x", "integer", desc="x (опц.)", required=False, default=0), P("y", "integer", desc="y (опц.)", required=False, default=0), P("clicks", "integer", desc="число кликов", required=False, default=1)], C)
def _(ctx, button, x, y, clicks):
    try:
        _mouse_click(x or None, y or None, button, clicks)
        return f"клик {button} x{clicks} в ({x},{y})"
    except Exception as e:
        return ToolResult(False, str(e))


@T("mouse_double_click", "Двойной клик", [P("x", "integer", desc="x", required=False, default=0), P("y", "integer", desc="y", required=False, default=0)], C)
def _(ctx, x, y):
    try:
        _mouse_click(x or None, y or None, "left", 2)
        return "двойной клик"
    except Exception as e:
        return ToolResult(False, str(e))


@T("mouse_move", "Переместить курсор (SetCursorPos / CGWarpMouseCursorPosition / xdotool mousemove)", [P("x", "integer", desc="x"), P("y", "integer", desc="y")], C)
def _(ctx, x, y):
    try:
        _mouse_move(x, y)
        return f"курсор в ({x},{y})"
    except Exception as e:
        return ToolResult(False, str(e))


@T("mouse_drag", "Перетащить с (x1,y1) на (x2,y2) - pyautogui.dragTo", [P("x1", "integer", desc="откуда x"), P("y1", "integer", desc="откуда y"), P("x2", "integer", desc="куда x"), P("y2", "integer", desc="куда y")], C)
def _(ctx, x1, y1, x2, y2):
    if _PA:
        _PA.moveTo(x1, y1)
        _PA.drag(x2 - x1, y2 - y1, duration=0.3)
        return "перетащено"
    if NT:
        _mouse_move(x1, y1)
        _send([_mouse_input(0x0002)])
        for step in range(1, 11):
            _mouse_move(x1 + (x2 - x1) * step // 10, y1 + (y2 - y1) * step // 10)
            time.sleep(0.02)
        _send([_mouse_input(0x0004)])
        return "перетащено"
    return _err_os()


@T("mouse_scroll", "Прокрутка колесом (clicks>0 вверх) - pyautogui.scroll / AutoIt MouseWheel", [P("clicks", "integer", desc="тики")], C)
def _(ctx, clicks):
    if _PA:
        _PA.scroll(clicks)
        return f"прокрутка {clicks}"
    if NT:
        _send([_mouse_input(0x0800, data=int(clicks * 120))])
        return f"прокрутка {clicks}"
    if LNX and _need("xdotool"):
        _sh(["xdotool", "click", "--repeat", str(abs(clicks)), "4" if clicks > 0 else "5"])
        return f"прокрутка {clicks}"
    return _err_os()


@T("mouse_position", "Текущая позиция курсора (GetCursorPos / xdotool getmouselocation)", [], C)
def _(ctx):
    if _PA:
        return str(_PA.position())
    if NT:
        import ctypes.wintypes as wt
        p = wt.POINT()
        _u32.GetCursorPos(ctypes.byref(p))
        return f"({p.x},{p.y})"
    if LNX and _need("xdotool"):
        return _sh(["xdotool", "getmouselocation"])
    return _err_os()


# ---------------------------------------------------------------- клавиатура
def _type_text(text: str):
    if _PA:
        _PA.write(text, interval=0.01)
        return
    if NT:
        ins = []
        for ch in text:
            code = ord(ch)
            ins += [_key_input(code, 0x0004), _key_input(code, 0x0004 | 0x0002)]
        _send(ins)
        return
    if LNX and _need("xdotool"):
        _sh(["xdotool", "type", "--clearmodifiers", text])
        return
    if MAC:
        _sh(["osascript", "-e", f'tell app "System Events" to keystroke "{text}"'])
        return
    raise RuntimeError("нет бэкенда клавиатуры")


def _press_key(key: str, down: bool = True, up: bool = True):
    k = key.lower()
    if _PA:
        if down and up:
            _PA.press(k)
        elif down:
            _PA.keyDown(k)
        else:
            _PA.keyUp(k)
        return
    if NT:
        vk = VK.get(k) or (ord(k[0].upper()) if len(k) == 1 and (k.isalnum()) else None)
        if not vk:
            raise RuntimeError(f"не знаю клавишу: {key}")
        ins = []
        if down:
            ins.append(_key_input(vk, 0))
        if up:
            ins.append(_key_input(vk, 0x0002))
        _send(ins)
        return
    if LNX and _need("xdotool"):
        if down and up:
            _sh(["xdotool", "key", "--clearmodifiers", k])
        elif down:
            _sh(["xdotool", "keydown", k])
        else:
            _sh(["xdotool", "keyup", k])
        return
    if MAC:
        _sh(["osascript", "-e", f'tell app "System Events" to key code "{k}"'])
        return
    raise RuntimeError("нет бэкенда клавиатуры")


@T("keyboard_type", "Напечатать текст в активное окно (SendInput unicode / WScript SendKeys / xdotool type / System Events keystroke)", [P("text", desc="текст")], C, core=True)
def _(ctx, text):
    try:
        _type_text(text)
        return f"напечатано: {text[:60]}"
    except Exception as e:
        return ToolResult(False, str(e))


@T("keyboard_press", "Нажать клавишу (enter, tab, escape, win, alt, ctrl, shift, f5, a...) - pyautogui.press / AHK Send", [P("key", desc="клавиша")], C)
def _(ctx, key):
    try:
        _press_key(key)
        return f"нажато: {key}"
    except Exception as e:
        return ToolResult(False, str(e))


@T("keyboard_hotkey", "Комбинация клавиш через + (ctrl+c, win+d, alt+tab, ctrl+shift+esc) - pyautogui.hotkey / AHK Send ^c", [P("keys", desc="клавиши через +")], C, core=True)
def _(ctx, keys):
    parts = [p.strip().lower() for p in keys.split("+")]
    try:
        if _PA:
            _PA.hotkey(*parts)
            return f"комбинация: {keys}"
        if NT:
            ins = []
            for p in parts:
                vk = VK.get(p) or (ord(p[0].upper()) if len(p) == 1 else None)
                if not vk:
                    raise RuntimeError(f"не знаю клавишу: {p}")
                ins.append(_key_input(vk, 0))
            for p in reversed(parts):
                vk = VK.get(p) or (ord(p[0].upper()) if len(p) == 1 else None)
                ins.append(_key_input(vk, 0x0002))
            _send(ins)
            return f"комбинация: {keys}"
        if LNX and _need("xdotool"):
            _sh(["xdotool", "key", "+".join(parts)])
            return f"комбинация: {keys}"
        if MAC:
            mods = " ".join(f"{p} down" for p in parts[:-1])
            _sh(["osascript", "-e", f'tell app "System Events" to keystroke "{parts[-1]}" using {{{mods}}}'])
            return f"комбинация: {keys}"
        return _err_os()
    except Exception as e:
        return ToolResult(False, str(e))


@T("keyboard_key_down_up", "Зажать/отпустить клавишу", [P("key", desc="клавиша"), P("down", "boolean", desc="зажать (иначе отпустить)")], C)
def _(ctx, key, down):
    try:
        _press_key(key, down=down, up=not down)
        return f"{'зажата' if down else 'отпущена'}: {key}"
    except Exception as e:
        return ToolResult(False, str(e))


# ---------------------------------------------------------------- экран / OCR
# СКРИНШОТЫ И OCR ПЕРЕЕХАЛИ в app/tools/screen.py.
# Причины: (1) старый путь через `powershell -Command` показывал окно консоли и
# (2) использовал `$args[0]`, который в режиме `-Command` всегда пуст — файл
# скриншота не создавался вовсе. Новый модуль снимает экран напрямую через
# Win32 GDI (ctypes, ноль дочерних процессов) и добавляет захват конкретного
# окна, области, монитора и отдельной вкладки браузера.
# Тулзы: screen_screenshot, screen_capture_window, screen_capture_region,
#        screen_capture_monitor, screen_monitors_list, screen_windows_list,
#        screen_active_window_screenshot, screen_capture_delayed,
#        screen_capture_browser_tab, screen_capture_page_element,
#        screen_size, screen_pixel, ocr_screen, screen_info.


@T("ui_tree", "Дерево UI-элементов окна (accessibility/UIAutomation) - нужно pywinauto или pyatspi", [P("title", desc="часть заголовка окна")], C)
def _(ctx, title):
    try:
        from pywinauto import Application
        app = Application(backend="uia").connect(title_re=f".*{title}.*", timeout=5)
        win = app.top_window()
        lines = []
        for el in win.descendants()[:120]:
            lines.append(f"{el.element_info.control_type}: {el.element_info.name!r}")
        return "\n".join(lines) or "элементов нет"
    except Exception as e:
        return ToolResult(False, f"UIAutomation недоступна: {e} (pip install pywinauto)")


# ---------------------------------------------------------------- процессы / shell
@T("proc_list", "Список процессов (tasklist / ps / Get-Process)", [P("filter", desc="фильтр по имени", required=False, default="")], C)
def _(ctx, filter):
    if NT:
        out = _ps("Get-Process | Select-Object Id,ProcessName,WorkingSet64 | ConvertTo-Json -Compress")
        import json as _j
        try:
            rows = _j.loads(out)
        except Exception:
            return out[:4000]
        rows = [r for r in rows if filter.lower() in str(r.get("ProcessName", "")).lower()]
        return "\n".join(f"{r['Id']} {r['ProcessName']} {r.get('WorkingSet64', 0)//1024//1024}МБ" for r in rows[:80]) or "не найдено"
    out = _sh(["ps", "-eo", "pid,comm,%mem", "--sort=-%mem"])
    if filter:
        out = "\n".join(l for l in out.split("\n") if filter.lower() in l.lower())
    return out[:4000]


@T("proc_kill", "Завершить процесс по имени или PID (taskkill / pkill / Stop-Process)", [P("target", desc="имя или pid")], C)
def _(ctx, target):
    if NT:
        if target.isdigit():
            return _ps(f"Stop-Process -Id {target} -Force") or f"убит {target}"
        return _ps(f"Stop-Process -Name '{target}' -Force") or f"убит {target}"
    return _sh(["pkill", "-f", target]) or f"убит {target}"


@T("proc_start", "Запустить процесс/команду фоново (CreateProcess / Start-Process / open)", [P("cmd", desc="команда или путь")], C)
def _(ctx, cmd):
    if NT:
        winproc.popen(cmd, shell=True, detach=True)
        return f"запущено: {cmd}"
    winproc.popen(cmd, shell=True, detach=True)
    return f"запущено: {cmd}"


@T("shell_run", "Выполнить команду shell и вернуть вывод (CMD/PowerShell/bash, таймаут 30с)", [P("cmd", desc="команда")], C, core=True)
def _(ctx, cmd):
    try:
        r = winproc.run(cmd, shell=True, timeout=30)
        return f"rc={r.returncode}\n{(r.stdout or '')[:4000]}\n{(r.stderr or '')[:1500]}"
    except subprocess.TimeoutExpired:
        return ToolResult(False, "таймаут 30с")


@T("app_launch", "Открыть файл/URL/приложение ассоциированным способом (ShellExecute / xdg-open / open)", [P("target", desc="путь или url")], C)
def _(ctx, target):
    if NT:
        os.startfile(target)
    elif MAC:
        subprocess.Popen(["open", target])
    else:
        subprocess.Popen(["xdg-open", target])
    return f"открыто: {target}"


@T("clipboard_get_set", "Буфер обмена: прочитать или записать (win32clipboard / Set-Clipboard / pbcopy / xclip)", [P("text", desc="текст для записи (пусто = прочитать)", required=False, default="")], C)
def _(ctx, text):
    if text:
        if NT:
            _ps(f"Set-Clipboard -Value '{text.replace(chr(39), chr(39)*2)}'")
        elif MAC:
            p = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            p.communicate(text.encode())
        elif _need("xclip"):
            p = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
            p.communicate(text.encode())
        else:
            return ToolResult(False, "нет xclip")
        return "записано в буфер"
    if NT:
        return _ps("Get-Clipboard -Raw")
    if MAC:
        return _sh(["pbpaste"])
    if _need("xclip"):
        return _sh(["xclip", "-selection", "clipboard", "-o"])
    return _err_os()
