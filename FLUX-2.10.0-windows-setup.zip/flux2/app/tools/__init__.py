"""Агрегация всех семейств инструментов + единая точка входа."""
from __future__ import annotations

from . import registry  # noqa: F401
from .registry import P, REG, ToolResult, ToolSpec  # noqa: F401
from . import text      # noqa: F401,E402
from . import encode    # noqa: F401,E402
from . import convert   # noqa: F401,E402
from . import dt        # noqa: F401,E402
from . import math_tools  # noqa: F401,E402
from . import net       # noqa: F401,E402
from . import files     # noqa: F401,E402
from . import codrun    # noqa: F401,E402
from . import browser   # noqa: F401,E402
from . import search    # noqa: F401,E402
from . import voice     # noqa: F401,E402
from . import memory    # noqa: F401,E402
from . import formats   # noqa: F401,E402
from . import misc      # noqa: F401,E402
from . import computer  # noqa: F401,E402
from . import screen     # noqa: F401,E402   # экран/окно/область/монитор/вкладка
from . import timers     # noqa: F401,E402   # фоновый планировщик + звук
from . import page       # noqa: F401,E402   # карта страницы: нумерованные элементы + browser_act
from . import media      # noqa: F401,E402   # медиа: системный транспорт, клавиши, свой плеер
from . import exts       # noqa: F401,E402   # установленные расширения браузера
from . import guardian   # noqa: F401,E402   # страж ПК: автозапуск, политики, карантин

REG.build_idf()


def count() -> int:
    return len(REG.tools)
