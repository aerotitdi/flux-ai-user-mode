"""Файлы и система (23). Работает в песочнице data-каталога, если путь не абсолютный."""
from __future__ import annotations

import hashlib
import os
import platform
import shutil
import time

from ..config import app_dir
from .registry import P, REG, ToolResult

C = "files"
T = REG.tool
ROOT = lambda: os.path.join(app_dir(), "data")


def _safe(path: str) -> str:
    p = path if os.path.isabs(path) else os.path.join(ROOT(), path)
    p = os.path.realpath(p)
    if not (p == os.path.realpath(ROOT()) or p.startswith(os.path.realpath(ROOT()) + os.sep) or os.path.isabs(path)):
        raise PermissionError("вне песочницы")
    return p


@T("fs_list", "Список файлов/папок каталога", [P("path", desc="путь", required=False, default=".")], C)
def _(ctx, path):
    p = _safe(path)
    items = sorted(os.listdir(p))
    return "\n".join(f"{'D' if os.path.isdir(os.path.join(p,i)) else 'F'} {i}" for i in items[:200]) or "пусто"


@T("fs_tree", "Дерево каталога (до 3 уровней)", [P("path", desc="путь", required=False, default=".")], C)
def _(ctx, path):
    p = _safe(path)
    out = []
    for root, dirs, files in os.walk(p):
        depth = root[len(p):].count(os.sep)
        if depth > 2:
            dirs[:] = []
            continue
        out.append("  " * depth + os.path.basename(root) + "/")
        for f in files[:40]:
            out.append("  " * (depth + 1) + f)
    return "\n".join(out[:250])


@T("fs_read", "Прочитать файл (текст)", [P("path", desc="путь"), P("max_chars", "integer", desc="лимит", required=False, default=8000)], C)
def _(ctx, path, max_chars):
    with open(_safe(path), "r", encoding="utf-8", errors="replace") as f:
        return f.read(max_chars)


@T("fs_write", "Записать файл (создать/перезаписать)", [P("path", desc="путь"), P("content", desc="содержимое")], C)
def _(ctx, path, content):
    p = _safe(path)
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(content)
    return f"записано {len(content)} символов в {p}"


@T("fs_append", "Дописать в конец файла", [P("path", desc="путь"), P("content", desc="содержимое")], C)
def _(ctx, path, content):
    with open(_safe(path), "a", encoding="utf-8") as f:
        f.write(content)
    return "дописано"


@T("fs_delete", "Удалить файл или папку", [P("path", desc="путь")], C)
def _(ctx, path):
    p = _safe(path)
    if os.path.isdir(p):
        shutil.rmtree(p)
    else:
        os.remove(p)
    return f"удалено: {p}"


@T("fs_copy", "Копировать файл", [P("src", desc="откуда"), P("dst", desc="куда")], C)
def _(ctx, src, dst):
    shutil.copy2(_safe(src), _safe(dst))
    return "скопировано"


@T("fs_move", "Переместить/переименовать", [P("src", desc="откуда"), P("dst", desc="куда")], C)
def _(ctx, src, dst):
    shutil.move(_safe(src), _safe(dst))
    return "перемещено"


@T("fs_mkdir", "Создать каталог", [P("path", desc="путь")], C)
def _(ctx, path):
    os.makedirs(_safe(path), exist_ok=True)
    return "создано"


@T("fs_info", "Информация о файле (размер, даты)", [P("path", desc="путь")], C)
def _(ctx, path):
    st = os.stat(_safe(path))
    return f"размер={st.st_size} изменён={time.ctime(st.st_mtime)} создан={time.ctime(st.st_ctime)}"


@T("fs_hash", "Хеш файла (sha256)", [P("path", desc="путь")], C)
def _(ctx, path):
    h = hashlib.sha256()
    with open(_safe(path), "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


@T("fs_search_text", "Найти текст в файлах каталога (grep-lite)", [P("needle", desc="что искать"), P("path", desc="каталог", required=False, default=".")], C)
def _(ctx, needle, path):
    p = _safe(path)
    hits = []
    for root, _, files in os.walk(p):
        for f in files:
            fp = os.path.join(root, f)
            try:
                with open(fp, "r", encoding="utf-8", errors="ignore") as fh:
                    for i, line in enumerate(fh, 1):
                        if needle.lower() in line.lower():
                            hits.append(f"{fp}:{i}: {line.strip()[:120]}")
            except Exception:
                pass
            if len(hits) > 40:
                return "\n".join(hits)
    return "\n".join(hits) or "не найдено"


@T("fs_size", "Размер каталога суммарно", [P("path", desc="путь", required=False, default=".")], C)
def _(ctx, path):
    total = 0
    for root, _, files in os.walk(_safe(path)):
        for f in files:
            total += os.path.getsize(os.path.join(root, f))
    return f"{total} байт ({total/1024/1024:.2f} МБ)"


@T("fs_recent", "Последние изменённые файлы каталога", [P("path", desc="путь", required=False, default="."), P("limit", "integer", desc="сколько", required=False, default=10)], C)
def _(ctx, path, limit):
    p = _safe(path)
    items = []
    for root, _, files in os.walk(p):
        for f in files:
            fp = os.path.join(root, f)
            items.append((os.path.getmtime(fp), fp))
    items.sort(reverse=True)
    return "\n".join(f"{time.ctime(m)} {fp}" for m, fp in items[:limit])


@T("fs_exists", "Существует ли путь", [P("path", desc="путь")], C)
def _(ctx, path): return "да" if os.path.exists(_safe(path)) else "нет"


@T("sys_platform", "Информация о системе (ОС, python, cpu)", [P("query", desc="запрос пользователя")], C, core=False)
def _(ctx, query):
    import sys
    return f"ос={platform.platform()} python={sys.version.split()[0]} cpu={platform.processor() or platform.machine()} ядер={os.cpu_count()}"


@T("sys_cpu", "Загрузка CPU и память (если доступен psutil)", [P("query", desc="запрос пользователя")], C)
def _(ctx, query):
    try:
        import psutil
        return f"cpu={psutil.cpu_percent(interval=0.5)}% mem={psutil.virtual_memory().percent}% свободно={psutil.virtual_memory().available//1024//1024}МБ"
    except Exception:
        return f"cpu_cores={os.cpu_count()} (psutil не установлен)"


@T("sys_disk", "Свободное место на дисках", [], C)
def _(ctx):
    out = []
    for d in ("C:\\" if os.name == "nt" else "/"):
        u = shutil.disk_usage(d)
        out.append(f"{d} всего={u.total//2**30}ГБ свободно={u.free//2**30}ГБ")
    return "; ".join(out)


@T("sys_env_get", "Значение переменной окружения", [P("name", desc="имя переменной")], C)
def _(ctx, name): return os.environ.get(name, "(не задана)")


@T("sys_clipboard_set", "Положить текст в буфер обмена (Windows/powershell)", [P("text", desc="текст")], C)
def _(ctx, text):
    if os.name == "nt":
        import subprocess
        p = subprocess.Popen(["powershell", "-NoProfile", "-Command", "Set-Clipboard -Value $input"], stdin=subprocess.PIPE)
        p.communicate(text.encode("utf-8"))
        return "ok"
    return ToolResult(False, "только Windows")


@T("sys_clipboard_get", "Прочитать буфер обмена (Windows/powershell)", [], C)
def _(ctx):
    if os.name != "nt":
        return ToolResult(False, "только Windows")
    import subprocess
    r = subprocess.run(["powershell", "-NoProfile", "-Command", "Get-Clipboard"], capture_output=True, text=True)
    return r.stdout.strip()


@T("sys_open_file", "Открыть файл/URL ассоциированным приложением", [P("path", desc="путь или url")], C)
def _(ctx, path):
    p = path if path.startswith(("http://", "https://")) else _safe(path)
    os.startfile(p) if os.name == "nt" else os.system(f"xdg-open '{p}' &")
    return f"открыто: {p}"
