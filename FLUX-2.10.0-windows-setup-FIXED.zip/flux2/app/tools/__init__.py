"""Агрегация всех семейств инструментов + единая точка входа."""
from __future__ import annotations

import importlib
import logging

from . import registry  # noqa: F401
from .registry import P, REG, ToolResult, ToolSpec  # noqa: F401

_log = logging.getLogger("flux.tools")

# Порядок тот же, что у прежних прямых импортов. Изоляция нужна, чтобы исключение
# на импорте ОДНОГО семейства не роняло всё приложение (причина краша 2.10.0).
_FAMILIES = (
    "text", "encode", "convert", "dt", "math_tools", "net", "files", "codrun",
    "browser", "search", "voice", "memory", "formats", "misc", "computer",
    "screen", "timers", "page", "media", "exts", "guardian",
)

for _mod in _FAMILIES:
    try:
        importlib.import_module(f"{__name__}.{_mod}")
    except Exception:
        _log.exception("семейство тулзов «%s» не загрузилось — пропускаем его", _mod)

REG.build_idf()


def count() -> int:
    return len(REG.tools)
