"""Уведомления FLUX: ЗВУК + тост + событие в UI.

Три независимых канала, чтобы уведомление дошло всегда:
  1. `ui`     — событие в шину (app.events). Окно чата рисует тост и играет звук
               через Web Audio. Работает даже если в системе нет аудио-устройств,
               доступных бэкенду, и не требует разрешений ОС.
  2. `native` — звук средствами ОС. Windows: `winsound` (это WinAPI PlaySound,
               БЕЗ дочернего процесса -> нет ни окна консоли, ни лишней сигнатуры АВ).
               Linux: paplay/aplay/ffplay. macOS: afplay.
  3. `toast`  — системный тост (Windows WinRT через СКРЫТЫЙ PowerShell; macOS
               `display notification`; Linux `notify-send`). По умолчанию выключен
               на Windows: для unpackaged-приложения тост требует зарегистрированного
               AppUserModelID и часто молча не показывается, а UI-тост надёжнее.

Все WAV-файлы генерируются процедурно (чистый Python + array/zlib-free) и кэшируются
в `data/sounds/`. Никаких бинарных ассетов в репозитории и в инсталляторе ->
меньше размер, меньше эвристических срабатываний на «неизвестный медиа-ресурс».
"""
from __future__ import annotations

import math
import os
import shutil
import struct
import sys
import threading
import time
import wave
from array import array
from typing import Optional

from . import events
from .config import CONFIG, app_dir

NT = sys.platform == "win32"
MAC = sys.platform == "darwin"

SAMPLE_RATE = 22050

# ------------------------------------------------------------------ синтез WAV
def _tone(freq: float, dur: float, vol: float = 0.42, attack: float = 0.008,
          release: float = 0.06, harmonic: float = 0.22) -> array:
    """Один тон с экспоненциально-подобной огибающей (без щелчков на границах)."""
    n = max(1, int(SAMPLE_RATE * dur))
    out = array("h")
    two_pi = 2.0 * math.pi
    a = max(1, int(SAMPLE_RATE * attack))
    r = max(1, int(SAMPLE_RATE * release))
    amp = vol * 32767
    f2 = freq * 2.0
    for i in range(n):
        t = i / SAMPLE_RATE
        if i < a:
            env = i / a
        elif i > n - r:
            env = (n - i) / r
        else:
            env = 1.0
        s = math.sin(two_pi * freq * t) + harmonic * math.sin(two_pi * f2 * t)
        v = int(amp * env * s / (1.0 + harmonic))
        out.append(max(-32767, min(32767, v)))
    return out


def _silence(dur: float) -> array:
    return array("h", bytes(int(SAMPLE_RATE * dur) * 2))


def _mix(*parts: array) -> array:
    out = array("h")
    for p in parts:
        out.extend(p)
    return out


# Рецепты: имя -> последовательность (частота, длительность, громкость)
RECIPES: dict[str, list[tuple[float, float, float]]] = {
    # двухтональная сирена — трудно не услышать
    "alarm": [(880.0, 0.22, 0.45), (1174.7, 0.22, 0.45), (0.0, 0.09, 0.0),
              (880.0, 0.22, 0.45), (1174.7, 0.30, 0.45)],
    # мягкий «динь-дон»
    "chime": [(1046.5, 0.18, 0.38), (783.99, 0.42, 0.34)],
    # короткий клик (тики обратного отсчёта)
    "tick": [(1600.0, 0.045, 0.22)],
    # завершение/успех — восходящее трезвучие
    "done": [(659.25, 0.13, 0.34), (830.6, 0.13, 0.34), (987.77, 0.30, 0.36)],
    # ошибка/отмена — нисходящее
    "error": [(440.0, 0.16, 0.34), (311.1, 0.34, 0.32)],
}

_cache: dict[str, str] = {}
_cache_lock = threading.Lock()


def sound_path(name: str) -> Optional[str]:
    """Путь к WAV (генерируется один раз и кэшируется на диске)."""
    name = (name or "alarm").lower()
    if name not in RECIPES:
        name = "alarm"
    with _cache_lock:
        if name in _cache and os.path.exists(_cache[name]):
            return _cache[name]
        try:
            d = os.path.join(app_dir(), "data", "sounds")
            os.makedirs(d, exist_ok=True)
            path = os.path.join(d, f"flux_{name}.wav")
            if not os.path.exists(path) or os.path.getsize(path) < 1000:
                parts = []
                for freq, dur, vol in RECIPES[name]:
                    parts.append(_silence(dur) if freq <= 0 else _tone(freq, dur, vol))
                data = _mix(*parts)
                tmp = path + ".tmp"
                with wave.open(tmp, "wb") as w:
                    w.setnchannels(1)
                    w.setsampwidth(2)
                    w.setframerate(SAMPLE_RATE)
                    w.writeframes(data.tobytes())
                os.replace(tmp, path)
            _cache[name] = path
            return path
        except Exception:
            return None


def duration_of(name: str) -> float:
    return sum(d for _, d, _ in RECIPES.get((name or "alarm").lower(), RECIPES["alarm"]))


# ------------------------------------------------------------------ проигрывание
_stop_flag = threading.Event()


def _play_native(path: str, repeat: int) -> bool:
    """Проиграть WAV средствами ОС. Возвращает True, если канал сработал."""
    from . import winproc
    try:
        if NT:
            import winsound
            flags = winsound.SND_FILENAME | winsound.SND_NODEFAULT
            if repeat <= 1:
                winsound.PlaySound(path, flags | winsound.SND_ASYNC)
                return True
            # SND_ASYNC не умеет повтор -> один поток на всю цепочку
            _stop_flag.clear()

            def loop():
                for _ in range(repeat):
                    if _stop_flag.is_set():
                        break
                    try:
                        winsound.PlaySound(path, flags)  # синхронно: между повторами можно прервать
                    except Exception:
                        break
            threading.Thread(target=loop, daemon=True, name="flux-sound").start()
            return True
        if MAC:
            exe = shutil.which("afplay")
            if exe:
                for _ in range(max(1, repeat)):
                    if _stop_flag.is_set():
                        break
                    winproc.popen([exe, path], detach=True)
                return True
        for exe in ("paplay", "aplay", "ffplay", "mpv", "play"):
            p = shutil.which(exe)
            if not p:
                continue
            argv = [p, path]
            if exe == "ffplay":
                argv = [p, "-nodisp", "-autoexit", "-loglevel", "quiet", path]
            elif exe == "mpv":
                argv = [p, "--no-video", "--really-quiet", path]
            elif exe == "play":
                argv = [p, "-q", path]
            for _ in range(max(1, repeat)):
                if _stop_flag.is_set():
                    break
                winproc.popen(argv, detach=True)
            return True
    except Exception:
        pass
    return False


def stop_sound() -> bool:
    """Немедленно оборвать звук (кнопка «Выключить» в тосте сработавшего таймера)."""
    _stop_flag.set()
    ok = False
    try:
        if NT:
            import winsound
            winsound.PlaySound(None, winsound.SND_ASYNC)   # штатная остановка PlaySound
            ok = True
        else:
            from . import winproc
            if shutil.which("pkill"):
                for victim in ("paplay", "aplay", "ffplay", "mpv", "play", "afplay"):
                    try:
                        winproc.run(["pkill", "-x", victim], timeout=5)
                        ok = True
                    except Exception:
                        pass
    except Exception:
        pass
    threading.Timer(1.5, _stop_flag.clear).start()
    return ok


def _beep_fallback(repeat: int = 2) -> bool:
    """Последний рубеж, если WAV-канал недоступен."""
    try:
        if NT:
            import winsound
            for i in range(max(1, repeat)):
                winsound.MessageBeep(winsound.MB_ICONASTERISK)
                if i + 1 < repeat:
                    time.sleep(0.25)
            return True
        sys.stdout.write("\a")
        sys.stdout.flush()
        return True
    except Exception:
        return False


_last_play = 0.0


def play(name: str = "alarm", repeat: int = 1, force: bool = False) -> str:
    """Проиграть звук. Возвращает имя канала: native|beep|none."""
    global _last_play
    mode = (CONFIG.settings.get("notify_sound") or "auto").lower()
    if mode == "off" and not force:
        return "none"
    now = time.time()
    if not force and now - _last_play < 0.35:
        return "none"           # защита от «пулемёта» при нескольких таймерах сразу
    _last_play = now
    path = sound_path(name)
    if path and mode in ("auto", "native", "both") and _play_native(path, repeat):
        return "native"
    if _beep_fallback(repeat):
        return "beep"
    return "none"


# ------------------------------------------------------------------ системный тост
_TOAST_PS = r"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$aumid = $a0
$xml = @"
<toast duration="long"><visual><binding template="ToastGeneric">
<text>$a1</text><text>$a2</text></binding></visual>
<audio silent="true"/></toast>
"@
$doc = New-Object Windows.Data.Xml.Dom.XmlDocument
$doc.LoadXml($xml.Replace('$a1', $a1).Replace('$a2', $a2))
$toast = New-Object Windows.UI.Notifications.ToastNotification $doc
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($aumid).Show($toast)
"""


def toast(title: str, body: str = "") -> bool:
    """Системный тост (опционально). По умолчанию на Windows выключен — см. докстринг модуля."""
    if not (CONFIG.settings.get("notify_toast") or False):
        return False
    try:
        if NT:
            from . import winproc
            aumid = os.environ.get("FLUX_AUMID") or "aerotitbit.Flux2.Desktop"
            winproc.ps(_TOAST_PS, args=[aumid, title[:120], body[:240]], timeout=12)
            return True
        if MAC:
            from . import winproc
            t = title.replace('"', "'")[:120]
            b = body.replace('"', "'")[:240]
            winproc.run(["osascript", "-e", f'display notification "{b}" with title "{t}"'], timeout=10)
            return True
        if shutil.which("notify-send"):
            from . import winproc
            winproc.run(["notify-send", "-a", "FLUX 2.0", title[:120], body[:240]], timeout=10)
            return True
    except Exception:
        pass
    return False


# ------------------------------------------------------------------ единая точка
def notify(kind: str, title: str, body: str = "", sound: str = "alarm",
           repeat: int = 1, data: Optional[dict] = None, silent: bool = False) -> dict:
    """Главная точка входа: звук + тост + событие в UI. Никогда не бросает исключений."""
    ev = {"type": "notify", "kind": kind, "title": title, "body": body,
          "sound": None if silent else sound, "repeat": repeat, "data": data or {}}
    channel = "ui"
    try:
        if not silent:
            ch = play(sound, repeat)
            ev["sound_channel"] = ch
            if ch != "none":
                channel = "native+ui"
        toast(title, body)
        events.publish(ev)
    except Exception as e:                     # уведомление не должно ронять приложение
        ev["error"] = f"{type(e).__name__}: {e}"
    ev["channel"] = channel
    return ev


def timer_fired(timer: dict) -> dict:
    """Специализированное уведомление о сработавшем таймере."""
    label = timer.get("label") or "таймер"
    body = timer.get("note") or ""
    if timer.get("overdue"):
        body = (body + " " if body else "") + f"(просрочен на {int(timer['overdue'])} с)"
    return notify("timer_fired", f"⏰ {label}", body,
                  sound=timer.get("sound_name") or "alarm",
                  repeat=int(timer.get("sound_repeat") or 2),
                  data={"timer_id": timer.get("id"), "label": label,
                        "due": timer.get("due"), "fired_count": timer.get("fired_count", 1),
                        "interval": timer.get("interval", 0)},
                  silent=not timer.get("sound", True))


def speak(text: str, timeout: float = 25.0) -> bool:
    """Озвучить текст голосом Flux (если TTS настроен).

    Зовётся из фонового потока таймера, где нет event loop, поэтому синхронизируем
    async-TTS в собственном одноразовом цикле. Ленивый импорт voicelab — без циклов.
    """
    engine = CONFIG.voice.get("tts_engine") or "off"
    if engine == "off" or not text.strip():
        return False

    def work() -> Optional[str]:
        import asyncio
        from . import voicelab
        loop = asyncio.new_event_loop()
        try:
            asyncio.set_event_loop(loop)
            return loop.run_until_complete(voicelab.synth_to_file(text))
        finally:
            try:
                loop.close()
            except Exception:
                pass

    try:
        box: dict = {}

        def runner():
            try:
                box["path"] = work()
            except Exception as e:
                box["err"] = str(e)

        t = threading.Thread(target=runner, daemon=True, name="flux-speak")
        t.start()
        t.join(timeout)
        path = box.get("path")
        if path and os.path.exists(path):
            return _play_native(path, 1)
    except Exception:
        pass
    return False


def selftest() -> dict:
    """Диагностика: какие каналы уведомлений реально доступны."""
    out = {"platform": sys.platform, "sounds_dir": os.path.join(app_dir(), "data", "sounds")}
    out["wav"] = bool(sound_path("alarm"))
    if NT:
        try:
            import winsound  # noqa: F401
            out["winsound"] = True
        except Exception:
            out["winsound"] = False
    else:
        out["players"] = [p for p in ("paplay", "aplay", "ffplay", "mpv", "afplay", "play")
                          if shutil.which(p)]
        out["notify_send"] = bool(shutil.which("notify-send"))
    out["notify_sound"] = CONFIG.settings.get("notify_sound", "auto")
    out["notify_toast"] = bool(CONFIG.settings.get("notify_toast"))
    return out
